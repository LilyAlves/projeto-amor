// História de amor
let anosDeNos = 7;
let sentimento = "amor infinito";
let mensagem = `
Há ${anosDeNos} anos nossos caminhos se cruzaram.
Desde então, cada dia ao seu lado é um presente.
Você é uma das pessoas mais incríveis que já conheci.
Eu te amo com todo o meu coração e desejo que nossa história
continue sendo escrita com muito ${sentimento}.
Para sempre nós. 💖
`;

const texto = document.getElementById("texto");
let i = 0;
function digitar() {
    if (i < mensagem.length) {
        texto.innerHTML += mensagem.charAt(i);
        i++;
        setTimeout(digitar, 50);
    }
}
window.onload = () => {
    digitar();
    criarCorações();
};

// Animação dos corações
function criarCorações() {
    const container = document.getElementById("coracoes");
    for (let j = 0; j < 20; j++) {
        const coracao = document.createElement("div");
        coracao.classList.add("coracao");
        coracao.style.left = Math.random() * 100 + "vw";
        coracao.style.animationDuration = (2 + Math.random() * 3) + "s";
        container.appendChild(coracao);
    }
    setTimeout(revelarFoto, 6000);
}

function revelarFoto() {
    document.getElementById("foto").classList.add("mostrar");
}
